package lab6;
import java.util.Scanner;

public class Lab64 {
	String alterString(String s1){
		char[] c = s1.toCharArray();
		String s2=new String();
		for (int i = 0; i < s1.length(); i++) {
			if (c[i] >= 'a' && c[i] <= 'z' || c[i] >= 'A' && c[i] <= 'z')
				if (!(c[i] == 'a' || c[i] == 'e' || c[i] == 'i' || c[i] == 'o' || c[i] == 'u' || c[i] == 'A'
						|| c[i] == 'E' || c[i] == 'I' || c[i] == 'O' || c[i] == 'U')) {
					c[i]=(char) (c[i]+1);
				}
			}
		return s2;
	}

	public static void main(String[] args) {
		System.out.println("enter a string");
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String s = sc.nextLine();
		Lab64 p=new Lab64();
		System.out.println(p.alterString(s));
		
	}

}

