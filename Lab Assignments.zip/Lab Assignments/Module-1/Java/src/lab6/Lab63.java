package lab6;

import java.util.Scanner;

public class Lab63 {

	String getImage(String a){
		StringBuilder s1=new StringBuilder(a);
		s1.reverse();
		String b=s1.toString();
		return b;
	}

	public static void main(String[] args) {
		System.out.println("enter the string");
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String s=sc.next();
		Lab63 p=new Lab63();
		System.out.println(s+" | "+p.getImage(s) );
		
	}

}

