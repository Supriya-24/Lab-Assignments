package lab1;

class Lab121
{
    public static int calculateDifference(int n)
    {
	int sum=0,sum2=0;
	for(int i=1;i<=n;i++)
	{
	   sum=sum+i;
	}
	int sum1=sum*sum;
	for(int i=1;i<=n;i++)
	{
	sum2=sum2+(i*i);
	}
	return -(sum2-sum1);
     }
}