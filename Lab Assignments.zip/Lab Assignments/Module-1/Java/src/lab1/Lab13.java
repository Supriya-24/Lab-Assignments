package lab1;

import java.util.Scanner;
class Lab13
{
     public static void main(String[] args)
     {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Number ");
	int number = sc.nextInt();
	if(Lab131.checkNumber(number))	
	   System.out.println("Number is in increasing order");
	else
	   System.out.println("Number is not in increasing order");
     }
}


	