package lab1;

import java.util.Scanner;
class Lab14
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the number ");
      int n = sc.nextInt();
      if(Lab141.checkNumber(n))
	System.out.println("Not a Power of 2");
      else
	System.out.println("power of 2");
    }
}

