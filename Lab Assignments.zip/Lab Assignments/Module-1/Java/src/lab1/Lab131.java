package lab1;

public class Lab131 {

    public static boolean checkNumber(int number)
    {
	int checkNum = number%10;
	number = number/10;
	while(number>0)
	{
	   if(checkNum<number%10)
	   {
		return false;
	    }
	checkNum = number%10;
	number = number/10;
	}
	return true;
     }
}