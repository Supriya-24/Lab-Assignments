package lab1;

import java.util.Scanner;
class Lab11
{
    public static void main(String[] args)
    {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the n value ");
	int n = sc.nextInt();
	System.out.println("Sum of natural numbers divided by 3 and 5 is "+Lab111.calculateSum(n));
     }
}

