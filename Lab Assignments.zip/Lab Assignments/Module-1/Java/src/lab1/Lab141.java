package lab1;

public class Lab141 {
   public static boolean checkNumber(int n)
   {
	if(n%3==0||n%5==0||n%7==0)
	   return true;
	else
	   return false;
   }
}