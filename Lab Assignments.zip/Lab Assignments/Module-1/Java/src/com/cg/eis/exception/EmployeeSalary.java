package com.cg.eis.exception;

import java.util.Scanner;

public class EmployeeSalary {
	static void validation(int sal) throws EmployeeException
	{
		if(sal<30000)
			throw new EmployeeException("Employee Salary is less than 30000");
		else
			System.out.println("Employee Salary is nore than 30000");
	}

	public static void main(String[] args) throws EmployeeException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Salary:");
		int n=sc.nextInt();
	EmployeeSalary.validation(n);
	System.out.println("rest of the code....");

	}

}


