
package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Throwable
{
	public EmployeeException(String errorMsg)
	{
		super(errorMsg);
	}
}
