package lab2;
class Video extends MediaItem {
	 private String director;
	 private String genre;
	 private int yearReleased;
	 void print() {
		 System.out.println("THERE IS A VEDIOROOM");
	 }
		 void addItem() {
			 System.out.println("A VIDEO IS ADDED");
		 }	
		
		  void checkIn() {
			 System.out.println("CHECKED IN TO WATCH A VIDEO");		 } 
		
		  void checkOut(){
			  System.out.println("check out AFTER WATCHING A VIDEO");
			 }  
	 
}

