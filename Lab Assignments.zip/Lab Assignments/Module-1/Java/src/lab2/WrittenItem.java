package lab2;

	abstract class WrittenItem  extends Item 
	{
		 String author;
	}
