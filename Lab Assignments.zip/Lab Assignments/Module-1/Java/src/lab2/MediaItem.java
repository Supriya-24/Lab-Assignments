package lab2;
abstract class MediaItem  extends Item {
	
}
