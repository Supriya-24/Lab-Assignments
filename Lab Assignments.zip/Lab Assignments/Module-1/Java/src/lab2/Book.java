package lab2;
class Book extends WrittenItem {
	 void print() {
		 System.out.println("library bokk bill is printed");
	 }
		 void addItem() {
			 System.out.println("book added in library");
		 }	
		
		  void checkIn() {
			 System.out.println("student checkin for a book");
		 } 
		
		  void checkOut(){
			  System.out.println("check out for a book");
			 }  
		  }

