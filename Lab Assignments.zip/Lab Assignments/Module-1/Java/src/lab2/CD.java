package lab2;
	class CD extends MediaItem 
	{
		private  String artist;
		 private String genre;
		 void print()
		 {
			 System.out.println("SOMEONE HAS ENTERED THE CD STORE");
		 }
		 void addItem()
		 {
				 System.out.println("CD IS ADDED");
		 }	
		  void checkIn() {
				 System.out.println("SOMEONE CHECKEDIN CD STORE");
			 } 
			
			  void checkOut(){
				  System.out.println("SOMEONE CHECKEDOUT OF CD STORE");
				 }
}


