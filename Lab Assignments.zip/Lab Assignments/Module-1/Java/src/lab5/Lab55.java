package lab5;
import java.util.Scanner;
class InvalidAgeException extends Throwable {
	public InvalidAgeException(String errorMsg) {
		super(errorMsg);
	}
}

public class Lab55 {
	static void validation(int age) throws InvalidAgeException {
		if (age < 15) {
			throw new InvalidAgeException("Exception thrown for invalid age");
		} else {
			System.out.println("valid age");
		}
	}

	public static void main(String[] args) throws InvalidAgeException {
				Scanner sc = new Scanner(System.in);
		System.out.println("enter age");
		Lab55.validation(sc.nextInt());

	}
}