package lab5;
import java.util.Scanner;
	class InvalidUserId extends Throwable {
		public InvalidUserId(String s) {
			super(s);
		}
	}
	public class Lab54 {
		static void login(String firstName, String lastName) throws InvalidUserId {
			if (firstName.equals("") | lastName.equals("")) {
				throw new InvalidUserId("enter valid name");
			} else {
				System.out.println("valid");
			}
		}
		
		public static void main(String[] args) throws InvalidUserId {
			System.out.println("first name");
			Scanner sc1 = new Scanner(System.in);
			String a=sc1.nextLine();
			System.out.println("last name");
			Scanner sc2 = new Scanner(System.in);
			String b=sc2.nextLine();
		    Lab54.login(a, b);

		}

	}



	
