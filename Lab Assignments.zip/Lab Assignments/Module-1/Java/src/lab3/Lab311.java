package lab3;

public class Lab311 {

   public static int getSecondSmallNumber(int[] a,int n)
   {
	for(int i=0;i<n;i++)
	{
	for(int j=i+1;j<n;j++)
	{
	   if(a[i]>a[j])
	   {
		int t = a[i];
		a[i] = a[j];
		a[j] = t;
	   }
	}
        }
     return a[1]; 
    }
}
