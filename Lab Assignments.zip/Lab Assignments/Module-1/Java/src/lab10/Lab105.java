package lab10;

import java.util.Scanner;
interface method_ref
{
	void show(int a);
}
public class Lab105 {
	void factorial(int n)
	{
		int fact=1;
		for(int i=1;i<=n;i++)
		{
			fact=fact*i;
		}
		System.out.println(fact);
	}
	public static void main(String[] args) {
		Lab105 d=new Lab105();
		method_ref m=d::factorial;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int a=sc.nextInt();
		m.show(a);
	}

}

