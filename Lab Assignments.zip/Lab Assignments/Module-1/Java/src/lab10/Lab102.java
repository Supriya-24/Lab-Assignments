package lab10;

import java.util.Scanner;
interface Space
{
	void words_space(String a);
}

public class Lab102 {
	public static void main(String[] args) {
		Space s=(a)->{
		for(int i=0;i<a.length();i++)
		{
			System.out.print(a.charAt(i)+" ");
		}
		};
		System.out.println("Enter the string");
		Scanner sc=new Scanner(System.in);
		String a=sc.next();
		s.words_space(a);
	}
}

