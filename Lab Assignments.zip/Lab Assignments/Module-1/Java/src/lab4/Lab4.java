package lab4;

import java.util.Scanner;
class Lab4
{
      public static void main(String[] args)
      {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter an n digit number ");
	int n=sc.nextInt();
	System.out.println("The Sum of Cubes Of all the Digits of the Number is "+Lab41.sumOfCubes(n));
       }
}

