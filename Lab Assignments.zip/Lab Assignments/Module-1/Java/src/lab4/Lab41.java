package lab4;

public class Lab41 {

	public static int sumOfCubes(int n)
	{
	int sum=0,rem=0;
	while(n!=0)
	{
	   rem=n%10;
	   sum=sum+(rem*rem*rem);
	   n=n/10;
	}
	return sum;
	}	
}